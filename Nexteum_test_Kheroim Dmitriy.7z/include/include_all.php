<?php ## подключить все
require_once("bdconnect_pdo.php"); // вызов подключения к бд
include ('SQL classes (new version).php'); // подключение файла для SQL запросов
include ('all_functions.php'); // подключение файла для SQL запросов
?>